I am Hendrik Schawe. I will present properties of the convex hulls of random
walks with a focus on the atypical regime.
For two dimensions this is already done, so let's look at higher dimensions.

0/12
This is a random walk, though it is rather atypical. Most random walks look
more compact.
To understand what this means in detail, we will first introduce the
simple isotropic *random walk* and what the *convex hull* is. Since we a
interested in the atypical cases, we need to introduce a clever *sampling*
technique before we come to the *results*.

1/12
We look at time discrete isotropic random walks. At each time step a random
displacement is drawn from a Gaussian distribution until we have *T* steps.
Importantly, this shows the same large *T* asymptotics as every other isotropic
random walk, for example on a lattice. Probably the most important property
is that one-dimensional properties like the end-to-end distance *r* scale
as the squareroot of the length *T*.
This simple model is well suited for diffusion and Brownian motion, but also
as a model for simple animals.

2/12
Imagine a microbe in a glass of water. This is what its trace could look like.
Every step has a random, independent length and direction.
Now, we need some simple observable to characterize this structure.

3/12
The convex hull of the visited points seems to be a good candidate
As the point set we use the visited sites of the random walk.
In the bottom left a simple algorithm to determine the convex hull is shown,
which works in arbitrary dimensions. But while in *d < 4* it is of
complexity *O(n log n)* it increases exponentially in the dimension.
Therefore "high dimensions" in this case means "not larger than 6".

4/12
The reason for this exponential increase is the number of facets of the
convex polytopes. Here is the convex hull of a three dimensional random
walk.
In two dimensions this is often used to estimate the home range of random
walking animals.
The most easy to interpret properties are the volume and surface of this hull.
Though one could imagine to measure the, say, oblateness, of the hull.
For Volume and surface the mean values are known exactly for large *T*.

5/12
This is the exact hypervolume. The right hand side is just a constant, so
the mean volume scales as *T^{d/2}*, which is plausible. Since one dimensional
properties scale as the squareroot of *T*, it is only natural that higher
dimensional properties scale as *sqrt(T)* to the *d*.
For the surface this is similar, though *d* is replaced by *d-1*.
We will now look numerically, not only at the means but at the full
distribution.

6/12
What does full distribution mean in this case? Well, since out steps are
Gaussian distributed and Gaussians are not bounded, we can not sample the
whole support. Though we will sample deep into the tails to probabilities
far smaller than, say, *10^{-100}*.
For that simple sampling, that is generating a random instance, measure it,
sort it into a histogram and repeating it a million times does not suffice,
since this enables us only to reach to *10^{-10}*.
But we can use a clever method like Wang Landau sampling.
This is a Markov chain Monte Carlo sampling, where we generate a realization,
change it slightly and accept this change with a Metropolis acceptance
probability dependent on an estimated density of states *g*.
Using this acceptance ratio will result in a flat histogram of visited
*S*, if the estimate of *g* is correct. Since we want to know *g*, we can
play it backwards and iteratively adapt *g* such that we get a flat histogram.

7/12
So in this example on the left is the histogram and on the right the current
estimate for the density of states. **start** Every time, we visit some value,
we increase *g* of this value, this way our sampling is biased to not visit
it again. The increment of *g* is lowered during the simulation.
As you can see, the distribution looks more and more like something we would
expect.

8/12
Originally the increment get rapidly smaller with this rule. But a problem
of this rapid decrease is that systematic caused by the violation of detailed
balance -- since the acceptance ratio changes during the simulation --
are introduced. Though a more recent article shows that this systematic
error can be avoided using a more moderat decrease of the increment.

9/12
Using this technique yields distributions like this for the hypervolume of
*d=4* convex hulls. So far no surprises: longer walks are more probable
to have larger volumes.
Thinking back to the exact results for the mean volume, which are basically
some power of the length, we should look, if the whole distribution
scales like this.

10/12
So with accordingly rescaled axis, we see that the peaks converge to some
limiting function and the right tail collapses. So this scaling seems to work
also for the right tail. Further we fitted this function to the right tails,
which fits nicely.

This is a straight forward generalization of the exactly known one dimensional
span. The span is the distance form the leftmost to the rightmost visited site.

11/12
The left tails seem to converge more slowly, but the fit to this obtained from
the left tail statistics of the span, fits ok.

12/12
In conclusion, the scaling of the means works for the whole distribution.
And the distribution of the volume of the convex hull behaves principally
the same as the distribution of the span of a one dimensional walk.
This analysis is very similar for multiple walks. More interestingly, we
have preliminary results for self interacting walks, like SAW and LERW.
If you are interested in this, I invite you to the poster session on Thursday.

13/12
Thanks for your attention. If you have any questions, feel free to ask!
