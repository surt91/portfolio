#!/bin/bash

for i in $(seq 1 800); do
name="$i"00
gnuplot << EOF
set term svg size 800,600 font "Verdana-Italic,25" linewidth 2
set output "$name.svg"
set ytics 1
unset key
unset ytics
unset xtics
set multiplot layout 1,3

set yl "count"
set xl "S"
set yr [0:400]
set rmargin 0.25
p "$name.H" w boxes lc 8

set yl "ln(g(V))"
set xl "S"
unset yr
set rmargin 0.7
set yr [0:174]
stats "$name.g" using 2 nooutput name 'Y_'
set arrow from screen 0.69, first 0 to 295, Y_min nohead
set arrow from screen 0.69, first 174 to 295, Y_max nohead
p "$name.g" w lp lc 8 pt 7 ps 0.4

set yl ""
set xl "S"
unset yr
unset arrow
unset rmargin
set lmargin screen 0.69
p "$name.g" w lp lc 8 pt 7 ps 0.4

unset multiplot

EOF
done
