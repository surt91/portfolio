for i in $(seq 1 500); do
echo "<img class=\"wangLandauFrame\" src=\"img/wl/"$i"00.svg\">"
done
