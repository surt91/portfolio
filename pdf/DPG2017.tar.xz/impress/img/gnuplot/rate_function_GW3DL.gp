load 'style.gps'

@TEX
set output "rate_function_GW3DL.tex"

set key bottom

unset margin

set xl '$s = \partial V/T^3$'
set yl '$\Phi$'

set format "$10^{%T}$"

a=1
b = 2./3
f(x) = a*x**b
fit f(x) "../data/rate/phi_inf_GW3DL.dat" u 1:2:3 yerr via a, b

set log xy

set xr [5e-4:1]
set yr [1e-3:2]

set label '$T=128$' rotate by -33 at 5e-3,4e-1
set label '$256$' rotate by -33 at 3.5e-3,1.6e-1
set label '$512$' rotate by -33 at 2.2e-3,7e-2
set label '$1024$' rotate by -33 at 1.2e-3,3.5e-2
set label '$2048$' rotate by -33 at 6e-4,1.8e-2

d = 3-1

smax(x) = x**d

plot \
    "../data/dist/WL_m2_t5_w1_d3_N128_n5.dat" u ($1/smax(128)):(-$3/128):(-$4/128) w p pt 7 ps 0.2 not "128", \
    "../data/dist/WL_m2_t5_w1_d3_N256_n5.dat" u ($1/smax(256)):(-$3/256):(-$4/256) w p pt 7 ps 0.2 not "256", \
    "../data/dist/WL_m2_t5_w1_d3_N512_n5.dat" u ($1/smax(512)):(-$3/512):(-$4/512) w p pt 7 ps 0.2 not "512", \
    "../data/dist/WL_m2_t5_w1_d3_N1024_n5.dat" u ($1/smax(1024)):(-$3/1024):(-$4/1024) w p pt 7 ps 0.2 not "1024", \
    "../data/dist/WL_m2_t5_w1_d3_N2048_n5.dat" u ($1/smax(2048)):(-$3/2048):(-$4/2048) w p pt 7 ps 0.2 not "2048", \
    "../data/rate/phi_inf_GW3DL.dat" u 1:2:3 w ye pt 1 lc 8 t 'Asymptotic $\Phi$', \
    [2e-3:] f(x) lt 1 t sprintf("$\\Phi = as^\\kappa, \\kappa = %.3f(%.0f), \\chi^2_{\\mathrm{red}} = %.1f$", b, b_err*1e3/FIT_STDFIT, FIT_STDFIT*FIT_STDFIT)
