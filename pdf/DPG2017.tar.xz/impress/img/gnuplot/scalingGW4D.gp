load 'style.gps'

@TEX
set output "scalingGW4D.tex"

unset margin

set multiplot

set xl "$V/T^{4/2}$"
set yl '$T^{4/2} p(V)$'
set format y "$10^{%.0f}$"

#set xr [:800]
set xr [:20000]
set yr [:5]

set xtics 5000

set key invert

d = 4
nu = 0.5*d
N = "32 64 128 256 512 1024 2048"
N = "2048 1024 512 256 128 64 32"
t = '\phantom{12}32 \phantom{12}64 \phantom{1}128 \phantom{1}256 \phantom{1}512 1024 2048'

plot for [i=1:7] "../data/dist/WL_m2_t5_w2_d4_N".word(N, i)."_n5.dat" u ($1/word(N, i)**nu):(($3+log(word(N, i)**nu))/log(10)):($2/word(N, i)**nu):($4/log(10)) w p pt 7 ps 0.5 t "$".word(N, i)."$"

set origin 0.23,0.16
set size 0.5,0.5

set border 3
set tics nomirror
unset key
unset xl
unset yl

set xtics 0.4
set xr [0:1.2]
set yr [0:5]

set format y "$%.0f$"

#replot
plot for [i=1:7] "../data/dist/WL_m2_t5_w2_d4_N".word(N, i)."_n5.dat" u ($1/word(N, i)**nu):(exp($3+log(word(N, i)**nu))):($2/word(N, i)**nu):(exp($3+log(word(N, i)**nu))*$4) w p pt 7 ps 0.2 not

unset multiplot
