load 'style.gps'

@TEX
set output "means.tex"

unset margin
set rmargin at screen 0.65

set size square
set key samplen 1. top outside Left reverse

set xl "$T$"
set yl '$\mu$'

set xr [:300000]

set yr [0:7]
set y2r [0:7]

#set y2l '$\mu_A$'

#set y2r [0:3]
#set ytics nomirror
#set y2tics nomirror

set log x

set key bottom

nu1 = 0.5
f1(x) = mu_c1 - a1*x**(-b1)
fit [128:] f1(x) "../data/simple/GRW2D.dat" u 1:($2/$1**nu1):($3/$1**nu1) yerr via a1, b1, mu_c1
chi1 = FIT_STDFIT

nu2 = 2*0.5
f2(x) = mu_c2 - a2*x**(-b2)
fit [256:] f2(x) "../data/simple/GRW3D.dat" u 1:($2/$1**nu2):($3/$1**nu2) yerr via a2, b2, mu_c2
chi2 = FIT_STDFIT

nu3 = 3*0.5
f3(x) = mu_c3 - a3*x**(-b3)
fit [1024:] f3(x) "../data/simple/GRW4D.dat" u 1:($2/$1**nu3):($3/$1**nu3) yerr via a3, b3, mu_c3
chi3 = FIT_STDFIT

nu7 = 4*0.5
f7(x) = mu_c7 - a7*x**(-b7)
fit [1024:] f7(x) "../data/simple/GRW5D.dat" u 1:($2/$1**nu7):($3/$1**nu7) yerr via a7, b7, mu_c7
chi7 = FIT_STDFIT

nu4 = 2*0.5
f4(x) = mu_c4 - a4*x**(-b4)
fit [128:] f4(x) "../data/simple/GRW2D.dat" u 1:($6/$1**nu4):($7/$1**nu4) yerr via a4, b4, mu_c4
chi4 = FIT_STDFIT

nu5 = 3*0.5
f5(x) = mu_c5 - a5*x**(-b5)
fit [256:] f5(x) "../data/simple/GRW3D.dat" u 1:($6/$1**nu5):($7/$1**nu5) yerr via a5, b5, mu_c5
chi5 = FIT_STDFIT

nu6 = 4*0.5
f6(x) = mu_c6 - a6*x**(-b6)
fit [1024:] f6(x) "../data/simple/GRW4D.dat" u 1:($6/$1**nu6):($7/$1**nu6) yerr via a6, b6, mu_c6
chi6 = FIT_STDFIT

nu8 = 5*0.5
f8(x) = mu_c8 - a8*x**(-b8)
fit [1024:] f8(x) "../data/simple/GRW5D.dat" u 1:($6/$1**nu8):($7/$1**nu8) yerr via a8, b8, mu_c8
chi8 = FIT_STDFIT


p "../data/simple/GRW2D.dat" u 1:($2/$1**nu1):($3/$1**nu1) w ye lc 1 lt 1 pt 4 t sprintf("$d=2, \\mu_{\\partial V}$", mu_c1, mu_c1_err*1e3/chi1, chi1**2), \
  f1(x) lc 1 lt 1 not, \
  "../data/simple/GRW3D.dat" u 1:($2/$1**nu2):($3/$1**nu2) w ye lc 2 lt 1 pt 6 t sprintf("$d=3, \\mu_{\\partial V}$", mu_c2, mu_c2_err*1e3/chi2, chi2**2), \
  f2(x) lc 2 lt 1  not, \
  "../data/simple/GRW4D.dat" u 1:($2/$1**nu3):($3/$1**nu3) w ye lc 3 lt 1 pt 8 t sprintf("$d=4, \\mu_{\\partial V}$", mu_c3, mu_c3_err*1e3/chi3, chi3**2), \
  f3(x) lc 3 lt 1  not , \
  "../data/simple/GRW5D.dat" u 1:($2/$1**nu7):($3/$1**nu7) w ye lc 4 lt 1 pt 10 t sprintf("$d=5, \\mu_{\\partial V}$", mu_c7, mu_c7_err*1e3/chi7, chi7**2), \
  f7(x) lc 4 lt 1  not , \
  "../data/simple/GRW2D.dat" u 1:($6/$1**nu4):($7/$1**nu4) w ye lc 1 lt 1 pt 5 t sprintf("$d=2, \\mu_V$", mu_c4, mu_c4_err*1e4/chi4, chi4**2), \
  f4(x) lc 1 lt 1 not , \
  "../data/simple/GRW3D.dat" u 1:($6/$1**nu5):($7/$1**nu5) w ye lc 2 lt 1 pt 7 t sprintf("$d=3, \\mu_V$", mu_c5, mu_c5_err*1e4/chi5, chi5**2), \
  f5(x) lc 2 lt 1 not , \
  "../data/simple/GRW4D.dat" u 1:($6/$1**nu6):($7/$1**nu6) w ye lc 3 lt 1 pt 9 t sprintf("$d=4, \\mu_V$", mu_c6, mu_c6_err*1e4/chi6, chi6**2), \
  f6(x) lc 3 lt 1 not, \
  "../data/simple/GRW5D.dat" u 1:($6/$1**nu8):($7/$1**nu8) w ye lc 4 lt 1 pt 11 t sprintf("$d=5, \\mu_V$", mu_c8, mu_c8_err*1e4/chi8, chi8**2), \
  f8(x) lc 4 lt 1 not
