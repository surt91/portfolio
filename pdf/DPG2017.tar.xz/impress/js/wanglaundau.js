var wanglandauInterval;
var wanglandauRunning = false;
var wanglandauIndex = 0;

function toggleWL() {
    if(!wanglandauRunning) {
        wanglandauRunning = true;
        var frames = document.getElementById("wanglandau").children;
        var frameCount = frames.length;

        wanglandauInterval = setInterval(function () {
            frames[quickhullIndex % frameCount].style.display = "none";
            frames[++quickhullIndex % frameCount].style.display = "block";
        }, 20);
    } else {
        clearInterval(wanglandauInterval);
        wanglandauRunning = false;
    }
}
