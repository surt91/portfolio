var wanglandauInterval;
var wanglandauRunning = false;
var wanglandauIndex = 0;

function toggleWL() {
    if(!wanglandauRunning) {
        wanglandauRunning = true;
        var frames = document.getElementById("wanglandau").children;
        var frameCount = frames.length;

        wanglandauInterval = setInterval(function () {
            frames[wanglandauIndex % frameCount].style.display = "none";
            frames[++wanglandauIndex % frameCount].style.display = "block";

            // stop at the last frame
            if(wanglandauIndex == frameCount-1) {
                clearInterval(wanglandauInterval);
            }
        }, 100);
    } else {
        clearInterval(wanglandauInterval);
        wanglandauRunning = false;
    }
}
