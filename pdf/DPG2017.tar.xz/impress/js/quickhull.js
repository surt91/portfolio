var quickhullInterval;
var quickhullRunning = false;
var quickhullIndex = 0;

function toggleQH() {
    if(!quickhullRunning) {
        quickhullRunning = true;
        var frames = document.getElementById("quickhull").children;
        var frameCount = frames.length - 1; // account for comment

        quickhullInterval = setInterval(function () {
            frames[quickhullIndex % frameCount].style.display = "none";
            frames[++quickhullIndex % frameCount].style.display = "block";
        }, 500);
    } else {
        clearInterval(quickhullInterval);
        quickhullRunning = false;
    }
}
